public class Test
{
    public static void main(String[] args) {
        Map map=new Map(3,6);
        map.setVisualBoard();
        map.show();
    }
}
