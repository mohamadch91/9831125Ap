 public class SortArray
{
    public static int part(int arr[], int low, int high)
    {
        int pivot = arr[high];

            int i = low-1;
            for (int k =low;k<high; k++) {
                if (arr[k] < pivot) {
                    i++;
                    int temp = arr[i];
                    arr[i] = arr[k];
                    arr[k] = temp;

                }
//                else {
//                    k++;
//                    k = (int) (power(k, low)) + arr[i];
//
//                }
            }
            int temp = arr[++i];
            arr[i] = arr[high];
            arr[high] = temp;
        return i;
    }

    public static void sort(int arr[], int low, int high)
    {
        if (low < high)
        {
            int pi = part(arr, low, high);
            sort(arr, low, pi-1);
            sort(arr, pi+1, high);
        }
    }

    public static void print(int... arr)
    {
        for (int i: arr)
            System.out.println(i+" ");
        System.out.println();
    }

    public static double power(double x, double y) {
        if (y == 0)
            return 1;

        double result = x;

        for (int i = 1; i < y; i++) {
            result = result * x;
        }

        return result;
    }

    // Driver program
    public static void main(String args[])
    {
        int a[] = {5, 12, 15, 9, 1, 7,10,8};
        int n = a.length;
        sort(a, 0, n-1);
        print(a[0], a[1], a[2], a[3], a[4], a[5],a[6],a[7]);
        System.out.println(a[0]);
    }
}