/** we use this class to show all book  in library
 * <h2>Library Book class</h2>
 * @author Mohamad choupan
 * @version 1.00
 * @since 1398-12-24
 */
public class Book {
    /**
     * @param title book title
     * @param author book author
     */
     private String title;
    private String author;
    public Book(String title,String author){
        this.title=title;
        this.author=author;
    }

    public String getTitle() {
        return title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getAuthor() {
        return author;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void print(){
        System.out.println("Title: "+title+" | Author: "+author);
    }
    // check book with author and title and write author first for lazy evaluating
    public int equal(String title,String author){
        /**
         * @param author we get it from user and compare with this book author
         * @param title to compare books
         * @return integer if books are equal return 1 else return 0
         */
        if((author==this.author)&&(title==this.title)){
            return 1;

        }
        else{
            return  0;
        }

    }
}
