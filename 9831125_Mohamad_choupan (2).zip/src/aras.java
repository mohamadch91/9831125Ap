import java.util.ArrayList;
import java.util.Iterator;

public class aras {
    public static void main(String args[]){
        ArrayList<Book> mamad=new ArrayList<Book>();
        Book book1 = new Book("slm","slm1");
        mamad.add(book1);
        Iterator<Book> it=mamad.iterator();
        System.out.println(it.hasNext());
    }
}
