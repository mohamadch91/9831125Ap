import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
/** we use these class to show all Library  in librarysystem
 * <h2>Library  class</h2>
 * @author Mohamad choupan
 * @version 1.00
 * @since 1398-12-24
 */
public class Libraray {
    /**
     * @param book this is list of all book in library
     * @param user this is list of all users in library
     * @param borrow this is list of all borrowed books in this library
     * @param name library name
     * @param address library address
     */
    private ArrayList<Book> book = new ArrayList<Book>();
    private ArrayList<User> user = new ArrayList<User>();
    private ArrayList<Borrow> borrow = new ArrayList<Borrow>();
    private String name;
    private String address;

    public Libraray(String name1, String address1) {
        name = name1;
        address = address1;
    }
//add user and check user are same or no

    public void addUser(User UserToAdd) {
        /**
         * this method add user to library and check new user already exist or no in library
         * @param chechk to check user already exist or no
         *
         */
        boolean check = false;
        Iterator<User> it = user.iterator();
        User test;
        while (it.hasNext()) {
            test = it.next();
            if (test.equal(UserToAdd.getIdNum()) == 1) {
                check = true;
                break;
            } else {
                check = false;
            }
        }
        if (!check) {
            user.add(UserToAdd);
        }
        else{
            System.out.println("This user already exist");
        }
    }
// remove user and check it has borrowed book currently or no
    public void removeUser(User UserToRemove) {
        /**
         * this method remove users from library and check if user borrow book and didnt give it back say user must give back
         * book
         * @param check check user exist
         * @param lastCheck check user borrowed book or not corrently
         */
        boolean check = false;
        Iterator<User> it = user.iterator();
        User test;
        while (it.hasNext()) {
            test = it.next();
            if (test.equal(UserToRemove.getIdNum()) == 1) {
                check = true;
                break;
            } else {
                check = false;
            }
        }
        if (check) {
            boolean lastCheck=false;
            for (Borrow m:borrow) {
                if(m.getBorrower().equal(UserToRemove.getIdNum())==1){
                    lastCheck=true;
                }

            }
            if(lastCheck){
                System.out.println("This user must Return Book");
            }
            else{
                user.remove(UserToRemove);
            }
        }
        else{
            System.out.println("this user does not exist");
        }
    }
// add book and check it same or not with correct books are in  list
    public void addBook(Book BookToAdd) {
        /** this method check book exist or no if it exist didnt add it
         * @param check for check book exist or no
         */
        Iterator<Book> it = book.iterator();
        boolean check = false;
        Book test;
        while ((it.hasNext())) {
            test = it.next();
            if ((test.equal(BookToAdd.getTitle(), BookToAdd.getAuthor())) == 1) {
                check = true;
            }

        }
        if (!check) {
            book.add(BookToAdd);
        }
        else{
            System.out.println("This book already exist");
        }
    }
// remove book and check its borrowed correctly or no and its in list or no
    public void removeBook(Book BookToRemove) {
        /** this param check this bookk exist in library
         * or not
         * and check its borrowed or no
         * @param check for check its in library or not
         * @param lastCheck for check its borrowed or not
         */
        Iterator<Book> it = book.iterator();
        boolean check = false;
        Book test;
        while ((it.hasNext())) {
            test = it.next();
            if ((test.equal(BookToRemove.getTitle(), BookToRemove.getAuthor())) == 1) {
                check = true;
            }

        }
        //this part is for check borrowed or not
        if (check) {
            boolean lastcheck=false;
            for (Borrow m:borrow) {
                if(m.getBook().equal(BookToRemove.getTitle(),BookToRemove.getAuthor())==1){
                    lastcheck=true;
                }
            }
            if(lastcheck){
                System.out.println("This book is brrowed");

            }
            else {
                book.remove(BookToRemove);
            }
        }
        else{
            System.out.println("This Book does not exist");
        }
    }
    //check borrow information are correct then borrow it
    public Borrow borrowBook(Book BookToBorrow, User Borrower, Date Deadline) {
        /** this method borrow book from library
         * @param BookToBorrow book which we want to borrow
         * @param borrower who borrrow the book
         * @param Deadline borrow deadline
         * @param fbook for check borrow informations and add it to borrow list
         * @param checkUser to check borrow user already in library or no
         * @param checkBook to check borrow vook already in library or no
         * @param checkBorrow to check this book borrowed or free
         * @return borrow for use it on give back method
         */
        Borrow fbook = new Borrow(Borrower, BookToBorrow, new Date(), Deadline);
        boolean checkUser = false;
        boolean checkBook = false;
        boolean checkBorrow=false;
        for (Book i : book) {
            if (i.equal(BookToBorrow.getTitle(), BookToBorrow.getAuthor()) == 1) {
                checkBook = true;
            }

        }
        for (User j : user) {
            if (j.equal(Borrower.getIdNum())==1) {
                checkUser = true;
            }

        }
        for (Borrow s:borrow) {
            if(s.getBook().equal(BookToBorrow.getTitle(),BookToBorrow.getAuthor())==1){
                checkBorrow=true;
            }

        }
        if (checkBook && checkUser&&(!checkBorrow)) {
            borrow.add(fbook);
            book.remove(fbook.getBook());
            return fbook;
        }
        else{
            System.out.println("Wrong request");
            fbook=null;
            return fbook;
        }
    }
    //checl book in library or no and in borrow list or no
    public void givebackBook(Borrow borrow) {
        /** this method is give back borrow
         * @param borrow the borrow user give to us to give it back
         * @param chechkborrow to check we have this borrow or not
         */
        boolean checkboroow=false;
        for (Borrow i: this.borrow) {
            if(i.equals(borrow)){
                checkboroow=true;
            }
        }
        if(checkboroow){
            this.borrow.remove(borrow);
            book.add(borrow.getBook());
        }
        else{
            System.out.println("this informations are wrong ");
        }
    }
    //print all borrows after they deadline
    public void printPassedDeadlineBorrows(){
        /** this method print all borrows which deadlines are passed
         * @param result to compare deadlines
         */
        for (Borrow k:borrow) {
            int result=k.getIssuedDate().compareTo(k.getDeadlineDate());
            if (result>=0){
                k.print();
            }
        }
    }

    public void setBook(ArrayList<Book> book) {
        this.book = book;
    }

    public ArrayList<Book> getBook() {
        return book;
    }

    public ArrayList<User> getUser() {
        return user;
    }

    public void setUser(ArrayList<User> user) {
        this.user = user;
    }

    public ArrayList<Borrow> getBorrow() {
        return borrow;
    }

    public String getAddress() {
        return address;
    }

    public String getName() {
        return name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setBorrow(ArrayList<Borrow> borrow) {
        this.borrow = borrow;
    }

    public void setName(String name) {
        this.name = name;
    }

}
