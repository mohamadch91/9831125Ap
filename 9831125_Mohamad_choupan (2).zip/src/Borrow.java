import java.time.LocalDate;
import java.util.Date;

/** we use this class to show all borrow in library
 * <h2>Library Borrow class</h2>
 * @author Mohamad choupan
 * @version 1.00
 * @since 1398-12-24
 */
public class Borrow {
    /**
     *
     * @param borrower to show who borrow book
     * @param book to show which book are borrowed
     * @param issuedDate to show which date book borrowed
     * @param deadlineDate to show when borrowen must return the book
     */
   private User borrower;
    private Book book;
    private Date issuedDate;
    private Date deadlineDate;
    //cunstructor method
    public Borrow(User borrower,Book book,Date issuedDate,Date deadlineDate){
        this.book=book;
        this.borrower=borrower;
        if(issuedDate.compareTo(deadlineDate)<=0){
        this.issuedDate=issuedDate;
        this.deadlineDate=deadlineDate;}
    }
    public Book getBook() {
        return book;
    }

    public Date getDeadlineDate() {
        return deadlineDate;
    }

    public Date getIssuedDate() {
        return issuedDate;
    }

    public User getBorrower() {
        return borrower;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public void setBorrower(User borrower) {
        this.borrower = borrower;
    }

    public void setDeadlineDate(Date deadlineDate) {
        this.deadlineDate = deadlineDate;
    }

    public void setIssuedDate(Date issuedDate) {
        this.issuedDate = issuedDate;
    }
    public void print(){
        /**
         * this method is used for print borrow information
         * @return nothing
         */
        // here we covert times to mili second then calculate Elapsed time then convert it to hour and minute from mili second
        long remainingD= (deadlineDate.getTime() - issuedDate.getTime());
        remainingD=remainingD/(60*1000);
        long  remainingh=(remainingD/60);
        remainingD=remainingh/24;
        remainingh=remainingD%24;
        System.out.println("Borrower => Full Name: "+borrower.getFirstname()+borrower.getLastname()+" | ID:"+borrower.getIdNum());
        System.out.println("Book=> Title:"+book.getTitle()+" | Author"+book.getAuthor());
        System.out.println("IssuedDate =>"+issuedDate);
        System.out.println("Deadline =>"+deadlineDate);
        System.out.println("Remaining =>"+"Day : "+(int)remainingD+" Hour :"+(int )remainingh);
        System.out.println("\n");
    }
}
