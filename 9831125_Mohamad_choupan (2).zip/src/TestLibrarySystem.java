import java.net.UnknownServiceException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;

/**
 * /** we use these class to show all Library  in librarysystem
 *  * <h2>Library  simulation  class</h2>
 *  * @author Mohamad choupan
 *  * @version 1.00
 *  * @since 1398-12-24
 *  */

public class TestLibrarySystem {
    public static void main(String args[]){
        /**in this method we test all posibilities to library system and we have 2
         * library 10 user 5 for each library and 10 book 5 for each library
         * @param flibs for user
         * @param slib for users of second library
         * @param boks for all book we have
         * @param bor borrows for use it on give back
         * @param test for simulation
         * @param libraries for two librarie we have
         */
        LibrarySystem test=new LibrarySystem();
        Libraray library1=new Libraray("Aut","Ce");
        Libraray library2=new Libraray("Tums","Medical");
        //first library users
        User flib=new User("mohamad","choupan","98311125");
        User flib1=new User("S","T","9831000");
        User flib2=new User("Armin","jalali","9831019");
        User flib3=new User("K","A","9831001");
        User flib4=new User("Sepehr","Tavakoli","983111");
        //second library users
        User slib=new User("mohamad1","choupan1","97311125");
        User slib1=new User("S1","T1","9731000");
        User slib2=new User("Armin1","jalali1","9731019");
        User slib3=new User("K1","A1","9731001");
        User slib4=new User("Sepehr1","Tavakoli1","973111");
        //ten book and i know that was book not bok
        Book bok=new Book("Computer","fisrt person");
        Book bok1=new Book("math","second porson");
        Book bok2=new Book("Physics","first person");
        Book bok3=new Book("story","third person");
        Book bok4=new Book("musics","nobody");
        Book bok5=new Book("sadstory","Me");
        Book bok6=new Book("lovestory","nobody");
        Book bok7=new Book("AP","dietel");
        Book bok8=new Book("C","dietel");
        Book bok9=new Book("PL","who??");
        flib.print();
        bok.print();
        //add libraries
        test.addLibrary(library1);
        test.addLibrary(library2);
        // add users to first library
        library1.addUser(flib);
        library1.addUser(flib1);
        library1.addUser(flib2);
        library1.addUser(flib3);
        library1.addUser(flib4);
        // wrong input
        library1.addUser(flib);
        // add users to second library and last one for check same use
        library2.addUser(slib);
        library2.addUser(slib1);
        library2.addUser(slib2);
        library2.addUser(slib3);
        library2.addUser(slib4);

        library2.addUser(slib);
        //add book to first library
        library1.addBook(bok);
        library1.addBook(bok2);
        library1.addBook(bok3);
        library1.addBook(bok4);
        library1.addBook(bok);
        //add bok to second library
        library2.addBook(bok5);
        library2.addBook(bok6);
        library2.addBook(bok7);
        library2.addBook(bok8);
        library2.addBook(bok9);

        library2.addBook(bok5);
        // add borrow for first library
        Calendar myCalendar = new GregorianCalendar(2021, 5, 11);
        Date myDate = myCalendar.getTime();
        Calendar myCalendar1 = new GregorianCalendar(2021, 6, 11);
        Date myDate1 = myCalendar.getTime();
        Borrow bor1=library1.borrowBook(bok,flib,myDate);
        Borrow bor2=library1.borrowBook(bok1,flib1,myDate1);
        Borrow bor3=library1.borrowBook(bok2,flib2,myDate);
        Borrow sbor=library2.borrowBook(bok5,slib1,myDate);
        //wrong borrow;

        Borrow bor4=library1.borrowBook(bok5,flib,myDate);

        Borrow bor5=library1.borrowBook(bok,slib,myDate);
        //borrow borrowed book

        Borrow bor6=library1.borrowBook(bok1,flib4,myDate);
        //expired borrow

        Borrow bor7=library1.borrowBook(bok2,flib3,new Date());
        //print borrow list
        Iterator<Borrow> it=library1.getBorrow().iterator();
        while (it.hasNext()){
            it.next().print();
        }
        library1.printPassedDeadlineBorrows();
        //remove user who borrowed book

        library1.removeUser(flib);
        //remove user who does not exist

        library1.removeUser(slib);
        //remove book borrowed

        library1.removeBook(bok1);

        //remove book does not exist

        library1.removeBook(bok7);
        //give back
        library1.givebackBook(bor1);
        //give bak book not borrowed
        Borrow test1=new Borrow(flib4,bok4,new Date(),myDate);
        library1.givebackBook(test1);
        //return borrow of first lib ro second lib

        library1.givebackBook(sbor);
        //remove user who give back book
        library1.removeUser(flib);
        //remove book not borrowed
        library1.removeBook(bok);
        test.printAllLibraries();
        test.removeLibrary(library1);
        test.printAllLibraries();
    }
}
