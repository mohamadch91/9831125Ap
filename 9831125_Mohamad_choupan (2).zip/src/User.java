/** we use this class to show all users in library
 * <h2>Library User class</h2>
 * @author Mohamad choupan
 * @version 1.00
 * @since 1398-12-24
 */
public class User {
    /**
     * @param firstname to know user name
     * @param lastname to know user last name
     * @param idNum it use to compare users
     */
    private String firstname;
    private String lastname;
    private String idNum;
    public User(String firstname,String lastname,String idNum){
        this.firstname=firstname;
        this.lastname=lastname;
        this.idNum=idNum;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getIdNum() {
        return idNum;
    }

    public String getLastname() {
        return lastname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public void setIdNum(String idNum) {
        this.idNum = idNum;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }
    public void print(){
        System.out.println("Full Name: "+lastname+firstname+" | ID : "+idNum);
    }
    // check users id to compare with other users and check its on library list or no
    public int equal(String idNum){
        /**
         * @param idNum we get it from user and compare with this user
         * @return integer if users are equal return 1 else return 0
         */
        if(idNum==this.idNum){
            return 1;
        }
        else{
            return 0;
        }
    }
}
