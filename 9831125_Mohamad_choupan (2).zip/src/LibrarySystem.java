import java.util.ArrayList;
import java.util.Iterator;
/** we use these class to show all Library  in librarysystem
 * <h2>LibrarySystem  class</h2>
 * @author Mohamad choupan
 * @version 1.00
 * @since 1398-12-24
 */
public class LibrarySystem {
    /**
     * @param library array of libraries
     * and methodes to add and remove libraries
     */
    private ArrayList<Libraray> library=new ArrayList<Libraray>();
    public void addLibrary(Libraray librarayToAdd){
        library.add(librarayToAdd);
    }
    public void removeLibrary(Libraray librarayToRemove){
        library.remove(librarayToRemove);
    }
    public void printAllLibraries(){
        Libraray test;
        Iterator<Libraray> it=library.iterator();
        while (it.hasNext()){
            test=it.next();
            System.out.println("name:"+test.getName()+" address "+test.getAddress());
            System.out.println("\n");
        }
    }

    public ArrayList<Libraray> getLibrary() {
        return library;
    }

    public void setLibrary(ArrayList<Libraray> library) {
        this.library = library;
    }
}
